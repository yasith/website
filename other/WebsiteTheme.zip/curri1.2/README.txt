--------------------------
CONTENT OF THIS FILE
--------------------------

 * Theme Info
 * Pages Provided
 * Key Features
 * Customisation
 * Credits
 * Issues & bug reporting
 * Stay up-to-date


--------------------------
THEME INFO
--------------------------

Name: Curri
Description: Stunning retina ready Curriculum Vitae or resume template for showcasing you & your skills.
Version 1.2
Released: July 2013
Creator: http://themelize.me
Bootstrap version: 2.3.2


--------------------------
PAGES PROVIDED (2)
--------------------------
* Index (index.htm)
* Elements (elements.htm)


--------------------------
KEY FEATURES
--------------------------

* Retina Ready!
* Built on Bootstrap 2.3.2
* Font Awesome icons 2.3.1
* IcoMoon Icons
* Fully responsive (wide, normal, narrow, mobile)
* Easy to customise
* Elements template to help you get started
* Starter CSS files
* Simple, bold, clean design
* Valid HTML5
* JSHint Compilant
* 2 preset colour skins
* Google font (OpenSans)
* jQuery Flexslider plugin
* Slick mobile menu
* One page scrolling 
* Experience Timeline
* Custom skills icons


--------------------------
CUSTOMISATION
--------------------------

1. Scrollable Sections
----------------------------------------------------
All section that you which to be scrollable to require 2 things:
1. An ID tag ie. id="contact"
2. A class of "scroll-section" ie. class="scroll-section"

Then you can link to this section using normal a tags with a href of #SECTION_ID
ie. <a href="#contact">Contact Me</a>


2. Adding Custom CSS Code & Colours
----------------------------------------------------
Don't like our styles & colours? Add your own!

Like all Themelize.me themes Curri offers and automatically loads a skeleton file called "custom-style.css" which should be used to override the theme structure, colours & media queries.
This file is found within the /css directory and is well commented to provide instruction.

NOTE: We highly recommend putting all your custom CSS code into this "custom-style.css" file to make future theme updates easy & simple without overwriting your own code.

For colour customisation examples see: css/alternative-colour.css file.


3. Adding New Pages
----------------------------------------------------
The main index.htm page is cleanly broken into sections so is easy to cut & paste the sections you order and change their ordering to create new pages.
Also see the elements.htm template for UI elements & CSS styles. 


4. Retina Images
----------------------------------------------------
Curri is retina (High Definition) ready and all images provided with the theme are also offered with a retina version.
To make your own images retina ready you just need to think double sized & appended @2x to the filename.

Here's an example:
* Standard definition size:     310px wide X 410px high
* High definition size:         620px wide X 820px high
* Standard definition filename: my-image.jpg
* High definition filename:     my-image@2x.jpg

Place both images in the same directory and the Retinajs plugin will automatically swap in the high definition version on device which support retina display.
NOTE: This is totally optional, if the plugin does not find a retina version of any images, the standard definition image is left.

For full image sizing info see img/README.txt file.

--------------------------
CREDITS
--------------------------

* Profile picture: http://www.flickr.com/photos/50424679@N00/8520590935/
* Work: http://www.isabelarodrigues.org (DO NOT REPRODUCE)
* Timeline: http://www.flickr.com/photos/vancouverfilmschool/
* Faces background: http://www.flickr.com/photos/50424679@N00/


--------------------------
ISSUES & BUG REPORTING
--------------------------

If you run into issues or find a bug which is not related to Bootstrap itself then please report the bug to us at info@themelize.me


--------------------------
STAY UP-TO-DATE
--------------------------
Join our mailing list at http://themelize.me to stay up-to-date with all our product launches & updates.